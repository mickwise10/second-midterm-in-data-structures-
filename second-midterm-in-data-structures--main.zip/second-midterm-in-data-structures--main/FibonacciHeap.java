package fibonacciHeap;
/**
 * FibonacciHeap
 *
 * An implementation of a Fibonacci Heap over integers.
 */
public class FibonacciHeap {
	
	// Class fields
	final static double GOLDEN_RATIO = (1 + Math.sqrt(5))/2;
	
	int size = 0;
	
	int marked = 0;
	
	int numOfTrees = 0;
	
	static int numOfLinks = 0;
	
	static int numOfCuts = 0;
	
	HeapNode min = null;
	
	HeapNode first = null;

	/**
	 * public boolean isEmpty()
	 *
	 * Returns true if and only if the heap is empty.
	 * 
	 */
	
	// O(1)
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * public HeapNode insert(int key)
	 *
	 * Creates a node (of type HeapNode) which contains the given key, and inserts
	 * it into the heap. The added key is assumed not to already belong to the heap.
	 * 
	 * Returns the newly created node.
	 */
	
	// O(1)
	public HeapNode insert(int key) {
		HeapNode newNode = new HeapNode(key);
		switch(size) {
		case(0): // Insert node to an empty heap
				min = newNode;
				first = newNode;
				numOfTrees = 1;
				size = 1;
				break;
		default: // Insert node at the begging of a non-empty heap
				newNode.setPrev(first.getPrev(), true);
				first.setPrev(newNode, true);
				first = newNode;
				this.setMin(newNode);
				size++;
				numOfTrees++;
		}
		return new HeapNode(key); 
	}

	/**
	 * public void deleteMin()
	 *
	 * Deletes the node containing the minimum key.
	 *
	 */
	
	// O(n)
	public void deleteMin() {
		
		// Delete the only node in a heap
		if (size == 1) {
			this.min.deleteNode();
			this.min = null;
			this.first = null;
			this.size = 0;
			this.numOfTrees = 0;
			return;
		}
		
		HeapNode deletedNodeNext = min.getNext();
		HeapNode deletedNodeChild = min.getChild();
		numOfTrees += this.min.deleteNode() - 1; // O(log(n))
		this.size--;
		
		// Set a new first node if needed
		if (this.min == this.first) {
			if (deletedNodeChild != null) {
				this.first = deletedNodeChild;
			}
			else {
				this.first = deletedNodeNext;
			}
		}
		this.min = this.first;
		HeapNode currentNode = first;
		
		/* Iterate through all roots to find the new minimum
		 * O(n) */
		do {
			this.setMin(currentNode);
			currentNode.setMark(false);
			currentNode = currentNode.getNext();
		}
		while (currentNode != first);
		
		/* Perform successive linking 
		 * O(n) */
		this.transformToAnotherHeap(this.consolidate());
	}

	/**
	 * public HeapNode findMin()
	 *
	 * Returns the node of the heap whose key is minimal, or null if the heap is
	 * empty.
	 *
	 */
	
	// O(1)
	public HeapNode findMin() {
		return this.min;
	}

	/**
	 * public void meld (FibonacciHeap heap2)
	 *
	 * Melds heap2 with the current heap.
	 *
	 */
	
	// O(1)
	public void meld(FibonacciHeap heap2) {
		HeapNode lastNodeFirstHeap = first.getPrev();
		HeapNode lastNodeSecondHeap = heap2.getFirst().getPrev();
		lastNodeFirstHeap.setNext(heap2.getFirst(), true);
		lastNodeSecondHeap.setNext(first, true);
		this.setMin(heap2.findMin()); // O(1)
		this.size = size + heap2.size();
	}

	/**
	 * public int size()
	 *
	 * Returns the number of elements in the heap.
	 * 
	 */
	
	// O(1)
	public int size() {
		return this.size; // should be replaced by student code
	}

	/**
	 * public int[] countersRep()
	 *
	 * Return an array of counters. The i-th entry contains the number of trees of
	 * order i in the heap. (Note: The size of of the array depends on the maximum
	 * order of a tree.)
	 * 
	 */
	//we at first deal with the possiblity of having a heap of size 0 or 1 , then we find the maximum
	// rank and create an array of this size, then we scan the roots and update the ranks in the array
	// we have to scans on the roots, we have maximum n roots , so the time complexity is O(n)
	public int[] countersRep() {
		int first_rank= this.first.rank;
		if(this.size==0)
		{
			int[] ar= new int[1];
			return ar;
		}
		if(this.numOfTrees == 1) {
			int ranks=this.first.getRank();
			int[] ar= new int[ranks+1];
			ar[ranks] = 1;
			return ar;
		}
		HeapNode node_itr= this.first.getNext();
		HeapNode start =this.first;
		while(node_itr!= start) {//find the maximum rank
			first_rank = Math.max(first_rank, node_itr.getRank());
			node_itr = node_itr.getNext();
		}

		node_itr = this.first.getNext();
		int[] ar= new int[first_rank+1];
		ar[this.first.getRank()] += 1;
		while(node_itr != this.first) {
			ar[node_itr.getRank()] += 1;
			node_itr = node_itr.getNext();
		}

		return ar;
	}

	/**
	 * public void delete(HeapNode x)
	 *
	 * Deletes the node x from the heap. It is assumed that x indeed belongs to the
	 * heap.
	 *
	 */
	
	// O(n)
	public void delete(HeapNode x) {
		if (x == min) {
			this.deleteMin(); // O(n)
		}
		else {
			int differenceFromMin = x.getKey() - min.getKey();
			this.decreaseKey(x, differenceFromMin + 1); // O(n)
			this.deleteMin(); // O(n)
		}
		
	}

	/**
	 * public void decreaseKey(HeapNode x, int delta)
	 *
	 * Decreases the key of the node x by a non-negative value delta. The structure
	 * of the heap should be updated to reflect this change (for example, the
	 * cascading cuts procedure should be applied if needed).
	 */
	
	// O(n)
	public void decreaseKey(HeapNode x, int delta) {
		x.setKey(x.getKey() - delta);
		if (x.getParent() == null){
			return;
		}
		if (x.getKey() < x.getParent().getKey()){
			this.cascadingCuts(x); // O(n)
		}
	}

	/**
	 * public int nonMarked()
	 *
	 * This function returns the current number of non-marked items in the heap
	 */
	
	// O(1)
	public int nonMarked() {
		return size - marked;
	}

	/**
	 * public int potential()
	 *
	 * This function returns the current potential of the heap, which is: Potential
	 * = #trees + 2*#marked
	 * 
	 * In words: The potential equals to the number of trees in the heap plus twice
	 * the number of marked nodes in the heap.
	 */
	
	// O(1)
	public int potential() {
		return numOfTrees + 2*marked; // should be replaced by student code
	}

	/**
	 * public static int totalLinks()
	 *
	 * This static function returns the total number of link operations made during
	 * the run-time of the program. A link operation is the operation which gets as
	 * input two trees of the same rank, and generates a tree of rank bigger by one,
	 * by hanging the tree which has larger value in its root under the other tree.
	 */
	
	// O(1)
	public static int totalLinks() {
		return numOfLinks; // should be replaced by student code
	}

	/**
	 * public static int totalCuts()
	 *
	 * This static function returns the total number of cut operations made during
	 * the run-time of the program. A cut operation is the operation which
	 * disconnects a subtree from its parent (during decreaseKey/delete methods).
	 */
	
	// O(1)
	public static int totalCuts() {
		return numOfCuts; // should be replaced by student code
	}


	// in this function, we do exactly the same as the main insert, the only change is that we keep
	// a pointer to the node in the original heap
	public HeapNode insert_for_min(int key,HeapNode p) {
		HeapNode newNode = new HeapNode(key);
		newNode.node_in_original_heap = p;
		switch(size) {
			case(0):
				min = newNode;
				first = newNode;
				numOfTrees = 1;
				size = 1;
				break;
			default:
				newNode.setPrev(first.getPrev(), true);
				first.setPrev(newNode, true);
				first = newNode;
				this.setMin(newNode);
				size++;
				numOfTrees++;
		}
		return new HeapNode(key);
	}
	/**
	 * public static int[] kMin(FibonacciHeap H, int k)
	 *
	 * This static function returns the k smallest elements in a Fibonacci heap that
	 * contains a single tree. The function should run in O(k*deg(H)). (deg(H) is
	 * the degree of the only tree in H.)
	 * 
	 * ###CRITICAL### : you are NOT allowed to change H.
	 */
	//here, we initalize a new heap and add the minimum, and his children to it, then we
	// delete the min and update the min once again, we do this k times, each time we add
	// the min to the i'th item in the array , and in the end we return the array
	// note that we always work on the new heap with the new node and new insert, thus the main heap doesn't change.
	public static int[] kMin(FibonacciHeap H, int k) {
		int[] ret_arr = new int[k];
		HeapNode f_child=H.first.getChild();
		FibonacciHeap sec_heap = new FibonacciHeap();
		if (H.size==0) {
			return new int[0];
		}
		if (f_child==null) {
			int[] sec_arr = new int[1];
			sec_arr[0]=H.min.getKey();
			return sec_arr;
		}

		sec_heap.insert_for_min(H.min.getKey(),H.first);//inserting and keeping a pointer
		HeapNode child_next=null;
		for(int i=0;i<k;i++) {


			HeapNode upd_min = sec_heap.min;//current minimum
			ret_arr[i] = upd_min.getKey();//insert the current minimum key to the array at  i
			sec_heap.deleteMin();
			if (upd_min.node_in_original_heap.getChild()!=null) {
				HeapNode from=upd_min.node_in_original_heap.getChild();
				child_next = from.getNext();//keep pointer to start at original binomial heap
				sec_heap.insert_for_min(from.getKey(),from);
				if (child_next == null)
					continue;

				while (child_next != from) {
					sec_heap.insert_for_min(child_next.getKey(), child_next);//we have a pointer to next child in the heap
					child_next = child_next.getNext();
				}
			}
		}
		return ret_arr;

	}
	
	// O(1)
	private void setMin(HeapNode otherNode) {
		if (size == 0) {
			this.min = null;
		}
		else if (otherNode.getKey() < min.getKey()) {
			min = otherNode;
		}
	}
	
	// O(1)
	public HeapNode getFirst() {
		return this.first;
	}
	
	// O(n)
	private void cascadingCuts(HeapNode cutNode) {
		HeapNode parent = cutNode.getParent();
		if (cutNode.getMark()) {
			marked--;
		}
		cutNode.cutNode();
		this.insertFirst(cutNode);
		if (parent.getMark()) {
			this.cascadingCuts(parent);
		}
		else {
			parent.setMark(true);
			marked++;
		}
	}
	
	
	// O(n)
	private FibonacciHeap consolidate() {
		HeapNode[] buckets = toBuckets(); // O(n)
		return fromBuckets(buckets); // O(log(n))
	}
	
	// O(n)
	private HeapNode[] toBuckets() {
		HeapNode[] buckets = new HeapNode[(calcLogGROfN(size)) + 1];
		first.getPrev().setNext(null, true);
		first.setPrev(null, true);
		HeapNode nextTree = first;
		HeapNode currentTree = null;
		
		/* Fill bucket array while performing successive linking 
		 * O(n) */
		do{
			currentTree = nextTree;
			nextTree = nextTree.getNext();
			int currentTreeRank = currentTree.getRank();
			while (buckets[currentTreeRank] != null) {
				currentTree = currentTree.link(buckets[currentTreeRank]);
				buckets[currentTreeRank] = null;
				currentTreeRank++;
			}
			buckets[currentTreeRank] = currentTree;
		} while (nextTree != null);
		return buckets;
	}
	
	// O(log(n))
	private FibonacciHeap fromBuckets(HeapNode[] buckets) {
		FibonacciHeap consolidatedHeap = new FibonacciHeap();
		consolidatedHeap.size = this.size;
		consolidatedHeap.marked = this.marked;
		numOfTrees = 0;
		
		// Connect roots to each other through buckets 
		this.connectBuckets(buckets); // O(log(n))
		for (int i = buckets.length - 1; i >= 0; i--) { // O(log(n))
			if (buckets[i] != null) {
				numOfTrees++;
				consolidatedHeap.insertFirst(buckets[i]); // O(1)
			}
		}
		return consolidatedHeap;
	}
	
	// O(1)
	public void insertFirst(HeapNode nodeToInsert) {
		
		// Insert into an empty list
		if (first == null) {
			first = nodeToInsert;
			min = nodeToInsert;
			numOfTrees = 1;
		}
		
		else {
			if (first.getPrev() != nodeToInsert) {
				first.getPrev().setNext(nodeToInsert, true);
			}
			first.setPrev(nodeToInsert, true);
			this.first = nodeToInsert;
			numOfTrees++;
			if (nodeToInsert.getKey() < min.getKey()) {
				this.setMin(nodeToInsert);
			}
		}
	}
	
	// O(1)
	public int calcLogGROfN(int n) {
		if (n == 0) {
			return 0;
		}
		if (n == 1) {
			return 1;
		}
		return (int) (Math.log(n)/Math.log(GOLDEN_RATIO));
	}
	
	// O(1)
	private void transformToAnotherHeap(FibonacciHeap otherHeap) {
		this.first = otherHeap.first;
		this.min = otherHeap.min;
		this.size = otherHeap.size;
		this.marked = otherHeap.marked;
		this.numOfTrees = otherHeap.numOfTrees;
	}
	
	// O(log(n))
	private void connectBuckets(HeapNode[] buckets) {
		int firstNonNullIndex = -1;
		int lastNonNullIndex = 0;
		for (int i = 0; i < buckets.length; i++) { // O(log(n))
			boolean noMoreNonNullIndexs = false;
			if (buckets[i] != null) {
				if (firstNonNullIndex == -1) {
					firstNonNullIndex = i;
					lastNonNullIndex = i;
				}
				for (int j = i + 1; j < buckets.length; j++) {
					if (buckets[j] != null) {
						buckets[i].setNext(buckets[j], true);
						i = j - 1;
						lastNonNullIndex = j;
						break;
					}
					else if(j == buckets.length -1) {
						noMoreNonNullIndexs = true;
						lastNonNullIndex = i;
						break;
					}
				}
				if (noMoreNonNullIndexs) {
					break;
				}
			}
		}
		
		buckets[lastNonNullIndex].setNext(buckets[firstNonNullIndex], true);
	}

	/**
	 * public class HeapNode
	 * 
	 * If you wish to implement classes other than FibonacciHeap (for example
	 * HeapNode), do it in this file, not in another file.
	 * 
	 */
	public static class HeapNode {
		
		// Class fields
		public int key;
		
		private int rank = 0;
		private boolean mark = false;

		public HeapNode node_in_original_heap;

		private HeapNode parent = null;
		
		private HeapNode child = null;

		private HeapNode next = this;

		private HeapNode prev = this;
		
		// Constructor
		public HeapNode(int key) {
			this.key = key;
		}
		
		// O(log(n))
		public int deleteNode() {
			int numOfNewTrees = 0;
			if (this.child != null) {
				HeapNode currChild = this.child;
				
				/* Insert children into the heap 
				 * O(log(n)) */
				do {
					currChild.setParent(this.parent, true);
					currChild = currChild.getNext();
					numOfNewTrees++;
				}while(currChild != this.child);
				if (this.next != this) {
					this.next.setPrev(this.child.getPrev(), true);
					this.prev.setNext(this.child, true);
				}
			}
			else {
				this.next.setPrev(prev, true);
			}
			this.parent = null;
			this.next = null;
			this.prev = null;
			this.child = null;
			return numOfNewTrees;
		}

		// O(1)
		public void cutNode() {
			numOfCuts++;
			if (this == this.parent.getChild()) {
				this.fixParentRanks();
			}
			this.mark = false;
			if (this.next == this) {
				this.parent.setChild(null, true);
			}
			else {
				if (this.parent.getChild() == this) {
					this.parent.setChild(this.next, false);
				}
				this.next.setPrev(this.prev, true);
			}
			this.parent = null;
		}
		
		private void fixParentRanks() {
			HeapNode currParent = this.parent;
			while (currParent != null) {
				currParent.setRank(currParent.getRank() - this.rank - 1);
				currParent = currParent.getParent();
			}
		}
		
		// O(1)
		public HeapNode link(HeapNode otherNode) {
			numOfLinks++;
			HeapNode smallerNode;
			HeapNode largerNode;
			if (otherNode.getKey() < this.getKey()) {
				smallerNode = otherNode;
				largerNode = this;
			}
			else {
				smallerNode = this;
				largerNode = otherNode;
			}
			if (smallerNode.getChild() != null) {
				largerNode.setPrev(smallerNode.getChild().getPrev(), true);
				largerNode.setNext(smallerNode.getChild(), true);
			}
			else {
				largerNode.setPrev(largerNode, true);
			}
			smallerNode.setChild(largerNode, true);
			smallerNode.setRank(smallerNode.rank + 1);
			smallerNode.setNext(smallerNode, true);
			smallerNode.setPrev(smallerNode, true);
			return smallerNode;	
		}
		
		/* Getters and setters 
		 * all O(1) */

		public void setKey(int key) {
			this.key = key;
		}

		public int getKey() {
			return this.key;
		}
		
		public void setRank(int rank) {
			this.rank = rank;
		}
		
		public int getRank() {
			return this.rank;
		}
		
		public void setMark(boolean mark) {
			this.mark = mark;
		}
		
		public boolean getMark() {
			return this.mark;
		}
		
		public void setParent(HeapNode parent, boolean firstCall) {
			this.parent = parent;
			if (parent != null && firstCall) {
				parent.setChild(this, false);
			}
		}
		
		public HeapNode getParent() {
			return this.parent;
		}
		
		public void setChild(HeapNode child, boolean firstCall) {
			this.child = child;
			if (child != null && firstCall) {
				child.setParent(this, false);
			}
		}
		
		public HeapNode getChild() {
			return this.child;
		}
		
		public void setNext(HeapNode next, boolean firstCall) {
			this.next = next;
			if (next != null && firstCall) {
				next.setPrev(this, false);
			}
		}
		
		public HeapNode getNext() {
			return this.next;
		}
		
		public void setPrev(HeapNode prev, boolean firstCall) {
			this.prev = prev;
			if (prev != null && firstCall) {
				prev.setNext(this, false);
			}
		}
		
		public HeapNode getPrev() {
			return this.prev;
		}
	}
}
